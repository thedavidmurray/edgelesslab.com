# MCP server template package
