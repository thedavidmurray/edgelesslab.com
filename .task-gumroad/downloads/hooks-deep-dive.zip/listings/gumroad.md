# Gumroad Product Listing -- Claude Code Hooks Deep Dive

> Copy-paste ready for Gumroad's product editor.
> Product type: Digital Product
> Category: Software & Development
> Price: $19

---

## Product Name

Claude Code Hooks Deep Dive -- 15 Production Hooks with Full Source

---

## Short Description

15 battle-tested Claude Code hooks from a system that runs 5 autonomous agents 24/7. The damage-control hook, the lie detector, the cost tracker, and 12 more -- with full source, walkthroughs, and deployment configs.

---

## Full Description

Most Claude Code hooks tutorials stop at "run a linter before commit." That's fine for a side project. It falls apart when you have agents making real decisions.

These hooks come from a production system that coordinates 5 autonomous AI agents across a Mac and a Hetzner VPS. One of those agents lost $252 of real money before the right hooks existed. Now it can't.

**What you get:**

15-chapter guide (~4,700 words) with 4 mermaid diagrams and the $252 postmortem sidebar, covering:

**Safety hooks:**
- damage-control.py -- blocks destructive commands in real-time (rm -rf, force push, DROP TABLE). Custom YAML parser, no external dependencies, fires on every tool call
- verify-completion.py -- evidence-based task verification. Agents must prove they're done, not just claim it. Default-to-FAIL philosophy

**Observability hooks:**
- post-tool-tracker.py -- logs every tool invocation to SQLite with secrets scrubbing. Your flight recorder
- trading-observer.py -- multi-agent financial tracking with risk levels and alerting
- sandbox-observer.py -- code execution monitoring with agent correlation

**Automation hooks:**
- skill-activation.py -- progressive skill disclosure based on prompt content (SHA256 config integrity)
- inbox-auto-claim.py -- multi-session dispatch with two-phase inbox claiming
- loop-stop-hook.py -- prevents accidental exit during iterative loops

**Preservation hooks:**
- pre-compact.py -- backs up critical context before compaction. Secrets scrubbed, FIFO rotation
- webfetch-archive.py -- archives web fetches to Obsidian with YAML frontmatter
- session-end.py -- forced retrospectives on significant sessions. Blocks exit until learning is captured

**Plus:**
- Hook composition patterns (chaining, conditional, environment-aware)
- 4 drop-in template hooks (pre-commit gate, cost tracker, notifications, secrets scanner)
- Complete deployment guide with settings.json examples
- patterns.yaml reference (25 dangerous command patterns, 3-tier path protection)
- SQLite schema for the observability stack

**Who this is for:**
- Developers using Claude Code who want more control over agent behavior
- Teams running autonomous agents that need safety guardrails
- Anyone who's been burned by an agent doing something destructive

**Who this is NOT for:**
- Complete beginners to Claude Code (start with the free Memory Kit)
- People who only use Claude Code for simple one-off tasks

**What you get:**
- guide.md (15 chapters, ~4,700 words, 4 mermaid diagrams)
- 11 production hooks + 4 customizable templates (15 Python files total, each runnable standalone)
- 7 shared library modules under `content/lib/`
- 3 config files (patterns.yaml, schema.sql, settings-example.json)
- README with copy-paste install walkthrough and working test commands
- CHANGELOG documenting known limitations and planned v1.1 items

All code is Python 3.10+ with zero external dependencies. That's intentional -- security hooks shouldn't depend on pip packages.

---

## Call to Action

Get the hooks that saved a production system from itself.
