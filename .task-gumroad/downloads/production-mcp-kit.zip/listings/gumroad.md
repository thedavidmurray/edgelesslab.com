# Gumroad Product Listing -- Production MCP Server Kit

> Copy-paste ready for Gumroad's product editor.
> Product type: Digital Product
> Category: Software & Development
> Price: $29

---

## Product Name

Production MCP Server Kit -- Auth, Rate Limiting, Docker, and Beyond

---

## Short Description

Take MCP servers past the tutorial stage. Auth middleware, rate limiting, Docker deployment, health checks, and error handling patterns from running 4+ MCP servers in production.

---

## Full Description

Every MCP tutorial shows you how to define a tool and return a result. None of them show you what breaks when two sessions hit the same endpoint, your API key leaks through error messages, or the server crashes at 3am with nobody watching.

This kit fills that gap. It comes from running 4+ MCP servers in production: a semantic search engine (Effect-TS + ChromaDB + SQLite fallback), an inter-session message router (SQLite + durable message queues), and utility servers that have survived months of daily use by autonomous agents.

**What you get:**

**3 production server templates:**

1. **Typed MCP Server (Effect-TS)** -- Schema-validated inputs, tagged errors via `Data.TaggedError`, dependency injection via Effect Layers, and a real SQLite-backed key-value store. Not a stub: a small but real implementation you can extend.

2. **API Proxy Server** -- Wraps external APIs with auth (key from env, never from prompts), in-memory rate limiting, response caching with TTL, and error sanitization that catches six classes of leaked secret (OpenAI, Bearer, api_key, GitHub PAT, AWS, JWT).

3. **Stateful Hub Server** -- Bun + `bun:sqlite` (WAL mode) durable message router. Lease/ack lifecycle, dead-letter queue, background sweeper, HTTP `/health` and `/metrics` endpoints on port 9800. The same architecture used in production by Agent Bus and similar inter-session message routers.

**Plus -- as real, runnable files, not snippets:**

- **`SubprocessBridge` (TypeScript)** -- Long-lived child process, JSON-RPC over stdin/stdout, per-call timeout, exit handler, backpressure. Pairs with the Python bridge already in `scripts/bridge.py`.
- **`fallback.ts`** -- ChromaDB -> SQLite FTS5 -> in-memory TF-IDF cascade with health-aware routing and exponential backoff. Real TypeScript file, not a guide snippet. Ships with passing tests.
- **Docker deployment** -- Multi-stage Dockerfile, Compose config, health checks against the actual `/health` endpoint in the stateful-hub template, persistent volume, non-root user.
- **17 passing tests** -- 13 in `api-proxy` (sanitizer + fallback cascade), 4 in `typed-server` (tagged errors).
- **5,500+ word guide** -- 11 chapters and 2 appendices, including three real production incident debriefs, an observability chapter (Prometheus shape), graceful shutdown recipes, and four mermaid architecture diagrams.

**Production patterns included:**
- Auth middleware: API keys from environment, never exposed to MCP protocol
- Rate limiting: per-tool, per-minute, with configurable thresholds
- Response caching: TTL-based with automatic eviction
- Error sanitization: 6 regex patterns catching OpenAI keys, Bearer tokens, api_key=, GitHub PATs, AWS access keys, and JWTs
- SQLite: WAL mode, prepared statements, busy timeout, lease/ack lifecycle, dead-letter queue
- Health endpoints: status, pending/leased/dead-letter counts, uptime, Prometheus `/metrics`
- Graceful shutdown: SIGTERM handler, in-flight drain, WAL checkpoint, bridge teardown

**Who this is for:**
- Developers building MCP servers that need to run reliably
- Teams deploying MCP servers to production environments
- Anyone who's outgrown the basic MCP tutorial examples

**Who this is NOT for:**
- Beginners still learning what MCP is (start with the MCP Starter Kit at $24)
- Projects that only need simple, single-use tools

All templates are TypeScript (Bun/Node compatible). Python bridge included. Docker configs included.

---

## Call to Action

Build MCP servers that survive production.
