# Gumroad Product Listing -- Generative Art Starter Kit

> Product type: Digital Product
> Category: Software & Development
> Price: $29

---

## Product Name

Generative Art Starter Kit -- 10 Python Generators for Pen Plotters

---

## Short Description

10 Python generators for pen plotters. 30 pre-plotted example SVGs, a 5,700-word guide with measured stroke-travel data and 30 named recipes, plus an AI scoring rubric distilled from 105+ autoresearch experiments.

---

## Full Description

Most generative art tutorials give you a script that makes pretty patterns on screen. They don't tell you how to make those patterns work on a pen plotter -- where stroke ordering matters, ink coverage needs to be in a specific range, and tiny details get lost in the mechanical precision of the pen.

This kit comes from 105+ experiments running an autoresearch loop across 75+ generators, scoring thousands of outputs to find what actually plots well.

**What you get:**

**10 working generators** (all ship as standalone Python files, all share a common `plotter_utils.py` module):
1. Flow Field -- Perlin noise particle traces, stdlib only
2. L-System Tree -- 5 presets (oak, willow, fern, bush, sierpinski)
3. Voronoi Cells -- Lloyd's relaxation (requires numpy + scipy)
4. Spiral Patterns -- Archimedean, logarithmic, hypotrochoid
5. Reaction-Diffusion -- Gray-Scott (spots, worms, coral, maze, zebra presets, requires numpy)
6. Subdivision Grid -- Vera Molnar-inspired recursive cuts
7. Subject-Driven Hatching -- NO background hatching, bring your own image or use the built-in mask
8. Space-Filling Curves -- Hilbert, Heighway dragon, Gosper flowsnake
9. Topographic Contours -- Multi-octave noise with ridged-multifractal mode (requires numpy)
10. Cellular Automata -- 1-D elementary rules (30, 90, 110, 184, etc.)

**30 pre-plotted example SVGs** (three seeds per generator) in `content/examples/`, each with its seed, parameters and plot time recorded in a `MANIFEST.md` alongside PNG previews for every file.

**5,700-word plotter-focused guide** (`content/guide.md`) with:
- Measured stroke-optimization before/after numbers (17-19x air-travel reduction on real output)
- Four mermaid diagrams (scoring pipeline, stroke-optimization comparison, L-system expansion, generator-selection tree)
- Failure-mode gallery (feed rate, wet ink, scoring rejects, re-plot cost)
- 30 named parameter recipes (three per generator, copy-paste CLI ready)
- AxiDraw + iDraw setup walkthroughs with pen pressure, feed rate, paper pairing
- An FAQ and a "common gotchas" section from nine months of autoresearch

**Production features:**
- SVG output optimized for plotters (single-stroke, no fills)
- Shared nearest-neighbor stroke ordering with measured 17-19x air-travel reduction
- Built-in plot-time estimator (+/- 15% vs real wall clock)
- Configurable paper sizes (A5, A4, A3, Letter) with margin-aware layout
- Metadata embedded in every SVG (seed, full parameter dump, path count, draw travel, air travel, plot time, pen)
- AI scoring script with Gemini and OpenAI providers, plus a real scoring log from a 10-piece gallery run (average 7.2 / 10)

**Scoring rubric from 105+ experiments:**
- 6 dimensions: composition, complexity, coherence, ink coverage, plottability, uniqueness
- Quality gates: 8+ = print immediately, 6-7.9 = worth plotting, < 4 = rework
- LLM scoring prompt included -- run it on your outputs

**Who this is for:**
- Developers with pen plotters (AxiDraw, iDraw, etc.) who want algorithmic art
- Creative technologists exploring the intersection of code and physical art
- Anyone curious about generative art with a focus on real output, not just screen renders

**Who this is NOT for:**
- If you want Processing/p5.js sketches, this is Python-only
- If you don't care about physical output, you won't use half the features

All generators are Python 3.10+. Core generators have zero dependencies. Advanced generators need numpy/scipy.

---

## Call to Action

From algorithm to paper in one command.
